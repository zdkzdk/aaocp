package cn.dc.customSerializer.bean;

public class ProductInfo {
    private Long product_id;
    private String product_name;
    private String extend_info;

    @Override
    public String toString() {
        return "ProductInfo{" +
                "product_id=" + product_id +
                ", product_name='" + product_name + '\'' +
                ", extend_info='" + extend_info + '\'' +
                '}';
    }

    public Long getProduct_id() {
        return product_id;
    }

    public void setProduct_id(Long product_id) {
        this.product_id = product_id;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getExtend_info() {
        return extend_info;
    }

    public void setExtend_info(String extend_info) {
        this.extend_info = extend_info;
    }
}
