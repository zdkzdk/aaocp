package cn.dc.customSerializer;

import cn.dc.customSerializer.bean.ProductInfo;
import cn.dc.customSerializer.bean.UserVisitAction;
import org.apache.flume.Context;
import org.apache.flume.Event;
import org.apache.flume.conf.ComponentConfiguration;
import org.apache.flume.sink.hbase.HbaseEventSerializer;
import org.apache.hadoop.hbase.client.Increment;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Row;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/*
Action日志从原始的格式经过转换存到HBase
一条日志对应一个ActionCustomFlumeHBaseSerializer对象。一条日志执行一次ActionCustomFlumeHBaseSerializer的getAction方法。虽然getAction返回的是List<Row>，但一般就朝里面放一条Row
 */
public class ProductCustomFlumeHBaseSerializer implements HbaseEventSerializer {
    private byte[] colFam="cf1".getBytes();
    private Event currentEvent;
    /*
    flume自动将event和设置的列族的名字传进来。bytes就是列族的字节数组
     */
    @Override
    public void initialize(Event event, byte[] bytes) {
        //byte[]字节型数组
        this.currentEvent = event;
        this.colFam = bytes;
    }
    /*
    这个方法的返回值就要要插入到hbase中的所有Row的集合，在这个方法中对event进行处理然后封装为Row对象
     */
    @Override
    public List<Row> getActions() {
        /*
        nginx中的格式转换 $http_host^A$request_uri
node6:81^A/action?date=2019-09-19&order_product_ids=39&session_id=f2847a39baab46da8ff8904cd7c42a7d&order_category_ids=44&page_id=1&action_tim
                                                              e=2019-09-19+4%3A27%3A00&click_category_id=-1&user_id=0&click_product_id=-1&city_id=7
         */
        String queryStr = new String(currentEvent.getBody());
       // String queryStr = "node6:81^A/action?date=2019-09-19&order_product_ids=39&session_id=f2847a39baab46da8ff8904cd7c42a7d&order_category_ids=44&page_id=1&action_tim\n" +
         //       "                                                              e=2019-09-19+4%3A27%3A00&click_category_id=-1&user_id=0&click_product_id=-1&city_id=7";
        String[] kvs = queryStr.substring(queryStr.indexOf("?") + 1).split("&");
        String[] kAndV = null;
        ProductInfo productInfo = new ProductInfo();
            for (String kv : kvs) {
                kAndV = kv.split("=");
                String fieldName = kAndV[0];
                String fieldValue = kAndV[1];
                Long fieldValueLong = null;

               try {
                   fieldValueLong = Long.valueOf(fieldValue);
               }catch (Exception e){
                   fieldValueLong = null;
               }

                /*
                private Long product_id;
    private String product_name;
    private String extend_info;
                */
                switch (fieldName) {
                    case "product_id": productInfo.setProduct_id(fieldValueLong);break;
                    case "product_name": productInfo.setProduct_name(fieldValue);break;
                    case "extend_info": productInfo.setExtend_info(fieldValue);break;

                }

            }
            /*
            至此，action对象封装完毕，下面开始向hbase插入
             */
        byte[] currentRowKey = UUID.randomUUID().toString().getBytes();

        List<Row> puts = new ArrayList<Row>();
        Put putReq = new Put(currentRowKey);

        putReq.add( colFam,  "product_id".getBytes(), productInfo.getProduct_id() != null ? productInfo.getProduct_id().toString().getBytes() : null);
        putReq.add( colFam,  "product_name".getBytes(), productInfo.getProduct_name() != null ? productInfo.getProduct_name().getBytes() : null);
        putReq.add( colFam,  "extend_info".getBytes(), productInfo.getExtend_info() != null ? productInfo.getExtend_info().getBytes():null);
        puts.add(putReq);
        return puts;

    }

    @Override
    public List<Increment> getIncrements() {
        List<Increment> incs = new ArrayList<Increment>();
        return incs;
    }

    @Override
    public void close() {
        colFam = null;
        currentEvent = null;
    }

    @Override
    public void configure(Context context) {

    }

    @Override
    public void configure(ComponentConfiguration componentConfiguration) {

    }

    public static void main(String[] args) {

    }



}
