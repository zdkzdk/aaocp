package cn.dc.customSerializer;

import cn.dc.customSerializer.bean.UserVisitAction;
import org.apache.flume.Context;
import org.apache.flume.Event;
import org.apache.flume.conf.ComponentConfiguration;
import org.apache.flume.sink.hbase.HbaseEventSerializer;
import org.apache.hadoop.hbase.client.Increment;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Row;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/*
Action日志从原始的格式经过转换存到HBase
一条日志对应一个ActionCustomFlumeHBaseSerializer对象。一条日志执行一次ActionCustomFlumeHBaseSerializer的getAction方法。虽然getAction返回的是List<Row>，但一般就朝里面放一条Row
 */
public class ActionCustomFlumeHBaseSerializer implements HbaseEventSerializer {
    private byte[] colFam = "cf1".getBytes();
    private Event currentEvent;

    /*
    flume自动将event和设置的列族的名字传进来。bytes就是列族的字节数组
     */
    @Override
    public void initialize(Event event, byte[] bytes) {
        //byte[]字节型数组
        this.currentEvent = event;
        this.colFam = bytes;
    }

    /*
    这个方法的返回值就要要插入到hbase中的所有Row的集合，在这个方法中对event进行处理然后封装为Row对象
     */
    @Override
    public List<Row> getActions() {
        /*
        nginx中的格式转换 $http_host^A$request_uri
node6:81^A/action?date=2019-09-19&order_product_ids=39&session_id=f2847a39baab46da8ff8904cd7c42a7d&order_category_ids=44&page_id=1&action_tim
                                                              e=2019-09-19+4%3A27%3A00&click_category_id=-1&user_id=0&click_product_id=-1&city_id=7
         */
        String queryStr = new String(currentEvent.getBody());
        // String queryStr = "node6:81^A/action?date=2019-09-19&order_product_ids=39&session_id=f2847a39baab46da8ff8904cd7c42a7d&order_category_ids=44&page_id=1&action_tim\n" +
        //       "                                                              e=2019-09-19+4%3A27%3A00&click_category_id=-1&user_id=0&click_product_id=-1&city_id=7";
        String[] kvs = queryStr.substring(queryStr.indexOf("?") + 1).split("&");
        String[] kAndV = null;
        UserVisitAction action = new UserVisitAction();
        for (String kv : kvs) {
            kAndV = kv.split("=");
            String fieldName = kAndV[0];
            String fieldValue = kAndV[1];
            Long fieldValueLong = null;

            try {
                fieldValueLong = Long.valueOf(fieldValue);
            } catch (Exception e) {
                fieldValueLong = null;
            }

                /*
                *   private String date;
                    private Long user_id;
                    private String session_id;
                    private Long page_id;
                    private String action_time;
                    private String search_keyword;
                    private Long click_category_id;
                    private Long click_product_id;
                    private String order_category_ids;
                    private String order_product_ids;
                    private String pay_category_ids;
                    private String pay_product_ids;
                    private Long city_id;*/
            switch (fieldName) {
                case "date":
                    action.setDate(fieldValue);
                    break;
                case "user_id":
                    action.setUser_id(fieldValueLong);
                    break;
                case "session_id":
                    action.setSession_id(fieldValue);
                    break;
                case "page_id":
                    action.setPage_id(fieldValueLong);
                    break;
                case "action_time":
                    action.setAction_time(fieldValue);
                    break;
                case "search_keyword":
                    action.setSearch_keyword(fieldValue);
                    break;
                case "click_category_id":
                    action.setClick_category_id(fieldValueLong);
                    break;
                case "click_product_id":
                    action.setClick_product_id(fieldValueLong);
                    break;
                case "order_category_ids":
                    action.setOrder_category_ids(fieldValue);
                    break;
                case "order_product_ids":
                    action.setOrder_product_ids(fieldValue);
                    break;
                case "pay_category_ids":
                    action.setPay_category_ids(fieldValue);
                    break;
                case "pay_product_ids":
                    action.setPay_product_ids(fieldValue);
                    break;
                case "city_id":
                    action.setCity_id(fieldValueLong);
                    break;
            }

        }
            /*
            至此，action对象封装完毕，下面开始向hbase插入
             */
        byte[] currentRowKey = UUID.randomUUID().toString().getBytes();

        List<Row> puts = new ArrayList<Row>();
        Put putReq = new Put(currentRowKey);


        putReq.add(colFam, "date".getBytes(), action.getDate() != null ? action.getDate().getBytes() : null);
        putReq.add(colFam, "user_id".getBytes(), action.getUser_id() != null ? action.getUser_id().toString().getBytes() : null);
        putReq.add(colFam, "session_id".getBytes(), action.getSession_id() != null ? action.getSession_id().getBytes() : null);
        putReq.add(colFam, "page_id".getBytes(), action.getPage_id() != null ? action.getPage_id().toString().getBytes() : null);
        putReq.add(colFam, "action_time".getBytes(), action.getAction_time() != null ? action.getAction_time().getBytes() : null);
        putReq.add(colFam, "search_keyword".getBytes(), action.getSearch_keyword() != null ? action.getSearch_keyword().getBytes() : null);
        putReq.add(colFam, "click_category_id".getBytes(), action.getClick_category_id() != null ? action.getClick_category_id().toString().getBytes() : null);
        putReq.add(colFam, "click_product_id".getBytes(), action.getClick_product_id() != null ? action.getClick_product_id().toString().getBytes() : null);
        putReq.add(colFam, "order_category_ids".getBytes(), action.getOrder_category_ids() != null ? action.getOrder_category_ids().getBytes() : null);
        putReq.add(colFam, "order_product_ids".getBytes(), action.getOrder_product_ids() != null ? action.getOrder_product_ids().getBytes() : null);
        putReq.add(colFam, "pay_category_ids".getBytes(), action.getPay_category_ids() != null ? action.getPay_category_ids().getBytes() : null);
        putReq.add(colFam, "pay_product_ids".getBytes(), action.getPay_product_ids() != null ? action.getPay_product_ids().getBytes() : null);
        putReq.add(colFam, "city_id".getBytes(), action.getCity_id() != null ? action.getCity_id().toString().getBytes() : null);
        puts.add(putReq);
        return puts;

    }

    @Override
    public List<Increment> getIncrements() {
        List<Increment> incs = new ArrayList<Increment>();
        return incs;
    }

    @Override
    public void close() {
        colFam = null;
        currentEvent = null;
    }

    @Override
    public void configure(Context context) {

    }

    @Override
    public void configure(ComponentConfiguration componentConfiguration) {

    }

    public static void main(String[] args) {

    }


}
